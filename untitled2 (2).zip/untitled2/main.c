#include <stdio.h>
#include <stdlib.h>
#include "uf.h"

int main(void) {

    FILE *f = abrir_arquivo();
    struct UF **ufs;


    int opcao;
    do {
        printf("Digite a opcao desejada:\n");
        printf("1 - Inserir uf\n");
        printf("2 - Imprimir uf\n");
        printf("3 - Inserir eleicao\n");
        printf("4 - Imprimir eleicao\n");
        printf("5 - Sair\n");
        scanf("%d", &opcao);


        switch (opcao) {
            case 1:
                criar_uf(f);
                break;
            case 2:
                mostrar_ufs(f);
                break;
            case 3:

                editar(ufs, f);
                break;
        }
    }while (opcao != 10);
    liberar_arquivo(ufs, f);

    return 0;
}
