//
// Created by SAMSUNG on 09/07/2025.
//

#ifndef UF_H
#define UF_H
#include <stdio.h>

struct UF{
    int codigo;
    char descricao[255];
    char sigla[4];
};

FILE *abrir_arquivo();
int para_ram(FILE *f, struct UF **ufs);
void liberar_arquivo(struct UF **ufs, FILE *f);
void criar_uf(FILE *f);
void mostrar_ufs(FILE *f);
int conferir(char *c, int max);
int comparar_int(int a, int total, struct UF **ufs);
int comparar_char(char *c,struct UF **ufs, int total);
int posicao(FILE *f, struct UF **ufs, int total, int codigo);
int buscar_posicao_por_codigo(FILE *f, int codigo_procurado, struct UF **ufs);
void editar(struct UF **ufs, FILE *f);
int buscar_por_codigo(struct UF **ufs, int total, int codigo);
struct UF **iniciaUF(FILE *f);
#endif //UF_H
