
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "pessoa.h"
#include "gerais.h"
#include "eleicao.h"

#include "uf.h"

void criar_eleicao(FILE *e, int excluidos_eleicoes, struct Eleicao **eleicoes, struct UF **ufs) {
    int total = para_ram_e(e, eleicoes);
    char continuar;
    int pos = total;
    do {
        eleicoes[pos] = malloc(sizeof(struct Eleicao));
        if (excluidos_eleicoes>0) {
            for (int i = 0; i <pos; i++) {
                if (strcmp(eleicoes[i]->descricao, "EXCLUIDO")==0) {
                    pos = i;
                    excluidos_eleicoes--;
                    break;
                }
            }
        }
        do {
            printf("Insira o ano: ");
            fflush(stdin);
            scanf("%d", &eleicoes[pos]->ano);
        }while (confere_ano(eleicoes, eleicoes[pos]->ano, total)==0);
        do {
            fflush(stdin);
            printf("Insira o codigo da uf: ");
            fflush(stdin);
            scanf("%d", &eleicoes[pos]->codigo_uf);
        }while (confere_codigo_uf1(eleicoes[pos]->codigo_uf,ufs,pos)==0);


        printf("digite a descricao: ");
        fflush(stdin);
        gets(eleicoes[pos]->descricao);

        fseek(e, pos*sizeof(struct Eleicao), SEEK_SET);
        fwrite(eleicoes[pos], sizeof(struct Eleicao), 1, e);
        if (pos==total) {
            pos++;
        }
        else {
            pos = total;
        }
        printf("Continuar? (s/n): ");
        scanf(" %c", &continuar);

    }while (continuar == 's' || continuar == 'S');
}


void mostrar_eleicoes(FILE *e, int capacidade) {
    struct Eleicao **eleicoes;
    eleicoes = malloc(sizeof(struct Eleicao *)*capacidade);
    int total = para_ram_e(e, eleicoes);
    printf("Tamanho: %d\n\n", total);
    printf("\n=== Eleicoes cadastradas ===\n");
    for (int i = 0; i < total; i++) {
        printf("Codigo: : %d\n", eleicoes[i]->codigo_uf);
        printf("Ano: %d\n", eleicoes[i]->ano);
        printf("Descricao: %s\n", eleicoes[i]->descricao);
        printf("Tamanho: %d\n\n", total);
    }

}


int confere_ano(struct Eleicao **eleicoes, int ano, int total){
    if (ano<1932) {
        printf("as primeiras eleicoes oficiais comecaram em 1932! digite outro ano\n");
        return 0;
    }
    for (int i = 0; i < total; ++i) {
        if (eleicoes[i]->ano ==ano) {
            printf("%d já está cadastrado!\n");
            return 0;
        }
    }
    return 1;
}

int confere_codigo_uf1(int inteiro, struct UF **ufs, int total) {
    for (int i= 0; i<total; i++) {
        if (ufs[i]->codigo== inteiro) {
            printf("%s ja existe! digite outro/outra. \n", inteiro);
            return 0;
        }
    }
    return 1;
}


int para_ram_e(FILE *e, struct Eleicao **eleicoes) {

    fseek(e, 0, SEEK_END);
    int tam = ftell(e);
    fseek(e, 0, SEEK_SET);
    int qtd = tam/sizeof(struct Eleicao);
    for (int i = 0; i < qtd; i++) {
        eleicoes[i] = malloc(sizeof(struct Eleicao));
        fread(eleicoes[i], sizeof(struct Eleicao), 1, e);
    }
    return qtd;
}
