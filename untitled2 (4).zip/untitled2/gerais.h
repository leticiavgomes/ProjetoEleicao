
//
// Created by Alunos on 16/07/2025.
//
#include <string.h>
#include <stdio.h>
#ifndef PROJETOELEICAO_GERAIS_H
#define PROJETOELEICAO_GERAIS_H
int confere_tam_char(char *ch, int tam);
int confere_vazio(char *ch);

#endif //PROJETOELEICAO_GERAIS_H
