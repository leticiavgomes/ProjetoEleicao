
#include <stdio.h>
#include <stdlib.h>

#include "gerais.h"
#include "uf.h"
#include "pessoa.h"
#include "eleicao.h"

int size(char path[], int sizeof_type);

int main() {

    FILE *f = abrir_arquivo("ufs.dat");
    FILE *p = abrir_arquivo("pessoas.dat");

    int excluidos_uf = 0;
    int excluidos_pessoas = 0;
    int capacidade = 30;

    struct UF **ufs;
    ufs = malloc(sizeof(struct UF *) * capacidade);
    struct Pessoa **pessoas;
    pessoas = malloc(sizeof(struct Pessoa*) * capacidade);
    fseek(f, 0, SEEK_END);
    fseek(p, 0, SEEK_END);
    do{
        ufs = realloc(ufs, sizeof(struct Pessoa*)*capacidade * 2);
    }while(ftell(f)/sizeof(struct UF)>=capacidade);

    for (int i = 0; i < capacidade; i++) {
        pessoas[i] = malloc(sizeof(struct Pessoa));
        fread(pessoas[i], sizeof(struct Pessoa), 1, p);
    }



    int qtd = size("ufs.dat", sizeof(struct UF));
    int qtd_pessoas = size("pessoas.dat", sizeof(struct Pessoa));

    for (int i = 0; i < qtd; i++) {
        ufs[i] = malloc(sizeof(struct UF));
        fread(ufs[i], sizeof(struct UF), 1, f);
    }

    FILE *e = abrir_arquivo("eleicoes.dat");
    int excluidos_eleicoes = 0;
    struct Eleicao **eleicoes;
    eleicoes = malloc(sizeof(struct Eleicao*) * capacidade);
    fseek(e, 0, SEEK_END);
    int qtd_eleicoes = size("eleicoes.dat", sizeof(struct Eleicao));
    do{
        eleicoes = realloc(eleicoes, sizeof(struct Eleicao*)*capacidade * 2);
    }while(qtd_eleicoes>=capacidade);
    for (int i = 0; i < qtd_eleicoes; i++) {
        eleicoes[i] = malloc(sizeof(struct Eleicao));
        fread(eleicoes[i], sizeof(struct Eleicao), 1, f);
    }




    int opcao;

    do {

        printf("1 - Inserir uf\n");
        printf("2 - Imprimir uf\n");
        printf("3 - Inserir eleicao\n");
        printf("4 - Buscar uf por codigo\n");
        printf("5 - Excluir UF\n");
        printf("6 - Inserir pessoa\n");
        printf("7 - Mostrar pessoas\n");
        printf("8 - Editar pessoa por CPF\n");
        printf("9 - Achar pessoa por titulo\n");
        printf("10 - Excluir pessoa por CPF\n");
        printf("Digite a opcao desejada:\n");
        scanf("%d", &opcao);
        getchar();


        switch (opcao) {
            case 1:
                para_ram(f, ufs);
                excluidos_uf = conta_uf_exc(ufs, qtd);
                printf("%d", excluidos_uf);
                criar_uf(f, excluidos_uf);
                break;
            case 2:
                mostrar_ufs(f, capacidade);
                break;
            case 3:
                editar(f, ufs, qtd);
                break;
            case 4:
                printf("digite o codigo: ");
                int codigo;
                scanf("%d", &codigo);
                buscar_por_codigo(ufs, qtd,codigo);
                break;
            case 5:
                excluir(f, ufs);
                break;
            case 6:
                para_ram_p(p, pessoas);
                excluidos_pessoas = conta_pessoa_exc(pessoas, qtd_pessoas);
                printf("%d", excluidos_pessoas);
                criar_pessoa(p, excluidos_pessoas, pessoas);
                break;
            case 7:
                mostrar_pessoas(p, capacidade);
                break;
            case 8:
                editar_p(p, pessoas,qtd_pessoas);
                break;
            case 9:
                para_ram_p(p, pessoas);
                printf("digite o titulo: ");
                char titulo[12];
                fflush(stdin);
                gets(titulo);
                buscar_por_titulo(pessoas, qtd_pessoas, titulo);
                break;
            case 10:
                excluir_p(p, pessoas, qtd_pessoas);
                break;
            case 11:
                criar_eleicao(e, excluidos_eleicoes, eleicoes, ufs);
                break;
            case 12:
                mostrar_eleicoes(e, capacidade);
                break;
        }

    }while (opcao != 15);
    liberar_arquivo(ufs, f);

    fclose(f);
    fclose(p);
    return 0;
}


int size(char path[], int sizeof_type){
    FILE *f = abrir_arquivo(path);
    fseek(f,0,SEEK_END);
    return ftell(f) / sizeof_type;
}
