//
// Created by SAMSUNG on 19/07/2025.
//

#ifndef VOTOS_H
#define VOTOS_H
struct voto{
    char numero_cand[7];
    char codigo_eleicao[10];
    char data_hora[15];
};

#endif //VOTOS_H
