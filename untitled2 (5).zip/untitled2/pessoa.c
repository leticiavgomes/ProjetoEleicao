//
// Created by Alunos on 16/07/2025.
//


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "pessoa.h"
#include "gerais.h"

void criar_pessoa(FILE *f, int excluidos_pessoa, struct Pessoa **pessoas) {
    int total = para_ram_p(f, pessoas);
    char continuar;
    int pos = total;
    do {
        pessoas[pos] = malloc(sizeof(struct Pessoa));
        if (excluidos_pessoa>0) {
            for (int i = 0; i <pos; i++) {
                if (strcmp(pessoas[i]->cpf, "EXCLUIDO")==0) {
                    pos = i;
                    excluidos_pessoa--;
                    break;
                }
            }
        }
        do {
            printf("Insira o CPF: ");
            fflush(stdin);
            gets(pessoas[pos]->cpf);
        }while (confere_tam_char(pessoas[pos]->cpf, 11)==0 || comparar_cpf(pessoas[pos]->cpf, pessoas, total, pos)==0);

        do {
            fflush(stdin);
            printf("Insira o titulo: ");
            gets(pessoas[pos]->titulo);
        }while (confere_tam_char(pessoas[pos]->titulo, 12)== 0|| comparar_titulo(pessoas[pos]->titulo, pessoas, total, pos)==0);

        do {
            printf("Insira o nome: ");
            fflush(stdin);
            gets(pessoas[pos]->nome);
        }while (confere_vazio(pessoas[pos]->nome)==0);
        printf("digite o fone: ");
        gets(pessoas[pos]->fone);
        printf("digite o endereco: ");
        gets(pessoas[pos]->endereco);
        printf("digite a data de nascimento: ");
        gets(pessoas[pos]->data_nasc);

        fseek(f, pos*sizeof(struct Pessoa), SEEK_SET);
        fwrite(pessoas[pos], sizeof(struct Pessoa), 1, f);
        fflush(f);
        if (pos==total) {
            pos++;
        }
        else {
            pos = total;
        }
        printf("Continuar? (s/n): ");
        scanf(" %c", &continuar);

    }while (continuar == 's' || continuar == 'S');
}

int comparar_cpf(char *c, struct Pessoa **pessoas, int total, int ignore_indice) {
    for (int i= 0; i<total; i++) {
        if (i==ignore_indice) {
            continue;
        }
        if (strcmp(pessoas[i]->cpf, c)==0) {
            printf("%s ja existe! digite outro/outra. \n", c);
            return 0;
        }
    }
    return 1;
}

int comparar_titulo(char *c, struct Pessoa **pessoas, int total, int ignore_indice) {
    for (int i= 0; i<total; i++) {
        if (i==ignore_indice) {
            continue;
        }
        if (strcmp(pessoas[i]->titulo, c)==0) {
            printf("%s ja existe! digite outro. \n", c);
            return 0;
        }
    }
    return 1;
}


int para_ram_p(FILE *p, struct Pessoa **pessoas) {

    fseek(p, 0, SEEK_END);
    int tam = ftell(p);
    fseek(p, 0, SEEK_SET);
    int qtd = tam/sizeof(struct Pessoa);
    for (int i = 0; i < qtd; i++) {
        pessoas[i] = malloc(sizeof(struct Pessoa));
        fread(pessoas[i], sizeof(struct Pessoa), 1, p);
    }
    return qtd;
}


void mostrar_pessoas(FILE *p, int capacidade) {
    struct Pessoa **pessoas;
    pessoas = malloc(sizeof(struct UF *)*capacidade);
    int total = para_ram_p(p, pessoas);
    printf("Tamanho: %d\n\n", total);
    printf("\n=== Pessoas cadastradas ===\n");
    for (int i = 0; i < total; i++) {
        printf("CPF: %s\n", pessoas[i]->cpf);
        printf("Titulo: %s\n", pessoas[i]->titulo);
        printf("Nome: %s\n", pessoas[i]->nome);
        printf("Fone: %s\n", pessoas[i]->fone);
        printf("Endereco: %s\n", pessoas[i]->endereco);
        printf("Data de Nascimento: %s", pessoas[i]->data_nasc);
        printf("Tamanho: %d\n\n", total);
    }

}

int buscar_por_cpf(struct Pessoa **pessoas, int total, char *achar_cpf) {
    for (int i = 0; i < total; i++) {
        if (strcmp(pessoas[i]->cpf, achar_cpf)==0) {
            printf("CPF: %s\n", pessoas[i]->cpf);
            printf("Titulo: %s\n", pessoas[i]->titulo);
            printf("Nome: %s\n", pessoas[i]->nome);
            printf("Fone: %s\n", pessoas[i]->fone);
            printf("Endereco: %s\n", pessoas[i]->endereco);
            printf("Data de Nascimento: %s", pessoas[i]->data_nasc);
            printf("Tamanho: %d\n\n", total);
            return i;
        }
    }
    printf("cpf nao encontrado!\n");
    return -1;
}


int buscar_por_titulo(struct Pessoa **pessoas, int total, char *achar_titulo) {
    for (int i = 0; i < total; i++) {
        if (strcmp(pessoas[i]->titulo, achar_titulo)==0) {
            printf("CPF: %s\n", pessoas[i]->cpf);
            printf("Titulo: %s\n", pessoas[i]->titulo);
            printf("Nome: %s\n", pessoas[i]->nome);
            printf("Fone: %s\n", pessoas[i]->fone);
            printf("Endereco: %s\n", pessoas[i]->endereco);
            printf("Data de Nascimento: %s", pessoas[i]->data_nasc);
            printf("Tamanho: %d\n\n", total);
            return i;
        }
    }
    printf("titulo nao encontrado!\n");
    return NULL;
}

void editar_p(FILE *f, struct Pessoa **pessoas, int total) {
    char *cod;
    printf("digite o CPF para edição: ");
    fflush(stdin);
    gets(cod);
    for (int i = 0; i < total; ++i) {
        if (strcmp(pessoas[i]->cpf, cod)==0) {
            printf("achei! \n");
            do {
                printf("Insira o CPF: ");
                fflush(stdin);
                gets(pessoas[i]->cpf);
            }while (confere_tam_char(pessoas[i]->cpf, 11)==0 || comparar_cpf(pessoas[i]->cpf, pessoas, total, i)==0);

            do {
                fflush(stdin);
                printf("Insira o titulo: ");
                gets(pessoas[i]->titulo);
            }while (confere_tam_char(pessoas[i]->titulo, 12)== 0|| comparar_titulo(pessoas[i]->titulo, pessoas, total, i)==0);

            do {
                printf("Insira o nome: ");
                fflush(stdin);
                gets(pessoas[i]->nome);
            }while (confere_vazio(pessoas[i]->nome)==0);
            printf("digite o fone: ");
            gets(pessoas[i]->fone);
            printf("digite o endereco: ");
            gets(pessoas[i]->endereco);
            printf("digite a data de nascimento: ");
            gets(pessoas[i]->data_nasc);

            fseek(f, i*sizeof(struct Pessoa), SEEK_SET);
            fwrite(pessoas[i], sizeof(struct Pessoa), 1, f);
            fflush(f);
            break;
        }
    }
    printf("CPF nao encontrado! ");
}

void excluir_p(FILE *f, struct Pessoa **pessoas, int total) {
    char *cpf_proc;
    int cod;
    fflush(stdin);
    printf("digite o CPF para excluir: ");
    gets(cpf_proc);
    cod = buscar_por_cpf(pessoas, total, cpf_proc);
    strcpy(pessoas[cod]->cpf, "EXCLUIDO");
    strcpy(pessoas[cod]->titulo, "--");
    strcpy(pessoas[cod]->nome, "--");
    strcpy(pessoas[cod]->fone, "--");
    strcpy(pessoas[cod]->endereco, "--");
    strcpy(pessoas[cod]->data_nasc, "--");
    fseek(f, cod*sizeof(struct Pessoa), SEEK_SET);
    fwrite(pessoas[cod], sizeof(struct Pessoa), 1, f);
    para_ram_p(f,pessoas);
    fflush(f);
}

int conta_pessoa_exc(struct Pessoa **pessoas, int total) {
    int excluido = 0;
    for (int i = 0; i < total; ++i) {
        if (strcmp(pessoas[i]->cpf,"EXCLUIDO")==0)
            excluido++;
    }
    return excluido;
}